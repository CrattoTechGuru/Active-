import { validateSplits, SplitValidationError } from '../src/services/splitEngine.service';

describe('validateSplits', () => {
  it('accepts splits that sum to exactly 100', () => {
    expect(() =>
      validateSplits([
        { collaboratorArtistId: 'a', percentage: 60 },
        { collaboratorArtistId: 'b', percentage: 40 },
      ])
    ).not.toThrow();
  });

  it('accepts splits with fractional percentages that sum to 100', () => {
    expect(() =>
      validateSplits([
        { collaboratorArtistId: 'a', percentage: 33.33 },
        { collaboratorArtistId: 'b', percentage: 33.33 },
        { collaboratorArtistId: 'c', percentage: 33.34 },
      ])
    ).not.toThrow();
  });

  it('rejects splits that sum to less than 100', () => {
    expect(() =>
      validateSplits([{ collaboratorArtistId: 'a', percentage: 90 }])
    ).toThrow(SplitValidationError);
  });

  it('rejects splits that sum to more than 100', () => {
    expect(() =>
      validateSplits([
        { collaboratorArtistId: 'a', percentage: 60 },
        { collaboratorArtistId: 'b', percentage: 60 },
      ])
    ).toThrow(SplitValidationError);
  });

  it('rejects an empty split list', () => {
    expect(() => validateSplits([])).toThrow(SplitValidationError);
  });

  it('rejects a duplicate collaborator', () => {
    expect(() =>
      validateSplits([
        { collaboratorArtistId: 'a', percentage: 50 },
        { collaboratorArtistId: 'a', percentage: 50 },
      ])
    ).toThrow(SplitValidationError);
  });

  it('rejects a zero or negative percentage', () => {
    expect(() =>
      validateSplits([
        { collaboratorArtistId: 'a', percentage: 0 },
        { collaboratorArtistId: 'b', percentage: 100 },
      ])
    ).toThrow(SplitValidationError);
  });

  it('does not false-positive on float drift (classic 0.1 + 0.2 case)', () => {
    // Regression guard: naive float summation without cent-rounding would
    // reject this as "99.99999999999999%".
    expect(() =>
      validateSplits([
        { collaboratorArtistId: 'a', percentage: 10 },
        { collaboratorArtistId: 'b', percentage: 20 },
        { collaboratorArtistId: 'c', percentage: 70 },
      ])
    ).not.toThrow();
  });
});
