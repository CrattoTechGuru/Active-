jest.mock('../src/config/database', () => ({
  pool: { query: jest.fn() },
}));

describe('cashOut', () => {
  const originalEnv = process.env;

  beforeEach(() => {
    jest.resetModules();
    process.env = { ...originalEnv };
  });

  afterAll(() => {
    process.env = originalEnv;
  });

  it('throws PayoutError without hitting the database when amount is invalid', async () => {
    const { cashOut, PayoutError } = await import('../src/services/payout.service');
    await expect(cashOut('artist-1', 0)).rejects.toThrow(PayoutError);
    await expect(cashOut('artist-1', -500)).rejects.toThrow(PayoutError);
  });

  it('throws a not_configured PayoutError when STRIPE_SECRET_KEY is missing', async () => {
    delete process.env.STRIPE_SECRET_KEY;
    const { cashOut, PayoutError } = await import('../src/services/payout.service');

    try {
      await cashOut('artist-1', 5000);
      fail('expected cashOut to throw');
    } catch (err) {
      expect(err).toBeInstanceOf(PayoutError);
      expect((err as InstanceType<typeof PayoutError>).reason).toBe('not_configured');
    }
  });

  it('records a failed payout with a clear reason when the artist has no connected Stripe account', async () => {
    process.env.STRIPE_SECRET_KEY = 'sk_test_dummy';
    const { pool } = await import('../src/config/database');
    (pool.query as jest.Mock).mockResolvedValueOnce({ rows: [{ stripe_connect_account_id: null }] });
    (pool.query as jest.Mock).mockResolvedValueOnce({ rows: [] }); // failure-row insert

    const { cashOut, PayoutError } = await import('../src/services/payout.service');

    try {
      await cashOut('artist-1', 5000);
      fail('expected cashOut to throw');
    } catch (err) {
      expect(err).toBeInstanceOf(PayoutError);
      expect((err as InstanceType<typeof PayoutError>).reason).toBe('no_connected_stripe_account');
    }

    // The failure was recorded, not silently swallowed.
    expect(pool.query).toHaveBeenCalledWith(
      expect.stringContaining('INSERT INTO payouts'),
      expect.arrayContaining(['artist-1', 5000, 'no_connected_stripe_account'])
    );
  });
});
